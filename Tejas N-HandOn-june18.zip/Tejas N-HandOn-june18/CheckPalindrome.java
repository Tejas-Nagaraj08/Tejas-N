package org.wipro.june18;
import java.util.Scanner;
public class CheckPalindrome {

	public static void main(String[] args) {
		int a=0;
		while(true)
		{
			System.out.println("Enter the value to check palindrome or not");
			Scanner sc=new Scanner(System.in);
			String message=sc.nextLine();
			char[] ch=message.toCharArray();
			int i=0,j=ch.length-1;
			while(i<j)
			{
				char x=ch[i];
				ch[i]=ch[j];
				ch[j]=x;
				i++;
				j--;	
			}
			String message1=new String(ch);
			String result=(message.equals(message1))?"Palindrome":"Not Palidrome";
			System.out.println(result);
			System.out.println("Press 1 for EXIT");
			a=sc.nextInt();
			if(a==1)
			{
				System.out.println("Successfully Exit....");
				break;
			}
		}
	}

}

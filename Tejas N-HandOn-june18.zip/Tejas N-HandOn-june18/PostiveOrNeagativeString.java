package org.wipro.june18;
import java.util.Scanner;

public class PostiveOrNeagativeString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(1==1)
		{
			System.out.println("Enter a String (or 'Exit' to quit)");
			String message=sc.nextLine().trim().toUpperCase();
			
			if(message.contains("EXIT"))
			{
				System.out.println("Sucessfully Exit.....");
				break;
			}
			String result=(isPostiveString(message))?" is Postive String":" is Negative String";
		System.out.println(message+" "+result);
		}
	}

	public static boolean isPostiveString(String message) {
		int n=message.length();
		for(int i=1;i<n;i++)
		{
			if(message.charAt(i)<message.charAt(i-1))
			{
				return false;
			}
		}
		return true;
	}

}

package org.wipro.june18;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		int a=0;
		while(true)
		{
			System.out.println("Enter the String value to Reverse");
			Scanner sc=new Scanner(System.in);
			String message=sc.nextLine();
			char[] ch=message.toCharArray();
			int i=0,j=ch.length-1;
			while(i<j)
			{
				char x=ch[i];
				ch[i]=ch[j];
				ch[j]=x;
				i++;
				j--;	
			}
			message=new String(ch);
			System.out.println("Reverse string value is:");
			System.out.println(message);
			System.out.println("Press 1 for EXIT");
			a=sc.nextInt();
			if(a==1)
			{
				System.out.println("Successfully Exit....");
				break;
			}
		}
	}

}

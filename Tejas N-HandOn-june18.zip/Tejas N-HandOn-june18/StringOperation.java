package org.wipro.june18;
import java.util.Scanner;
public class StringOperation {
	public static void main(String[] args) {
		
		int option;
		do
		{
			System.out.println("1.Add the String to itself");
			System.out.println("2.Replace odd postion with #");
			System.out.println("3.Remove duplicate character to upper case");
			System.out.println("4.Change odd character to upper case");
			System.out.println("5.Exit");
			Scanner sc=new Scanner(System.in);
			option=sc.nextInt();
			String str1="Hello";

			switch(option)
			{
			case 1:
				addStringvalue(str1);
				break;

			case 2:
				String replace=replaceWithHashOddPosition(str1);
				System.out.println(replace);
				break;

			case 3:
				String duplicate="";
				
				for(int i=0;i<str1.length();i++)
				{
					String temp=String.valueOf(str1.charAt(i));
					if(!duplicate.contains(temp))
						duplicate+=temp;
				}
				System.out.println(duplicate);
				break;

			case 4:
				System.out.println("4");
				char[] ch=str1.toCharArray();
				
				for(int i=0;i<ch.length;i++)
				{
					if((i+1)%2!=0)
						if(ch[i]>='a'&&ch[i]<='z')
							ch[i]=(char)(ch[i]-32);
				}
				String upper=new String(ch);
				System.out.println(upper);
				break;

			case 5:
				if(option==5)
					System.out.println("Successfully Exit.....");
					break;
			}
			System.out.println();
		}while(option!=5);
	}

	public static String replaceWithHashOddPosition(String str) {
		char[] ch=str.toCharArray();
		
		for(int i=0;i<ch.length;i++)
		{
			if((i+1)%2!=0)
				ch[i]='#';
		}
		
		return new String(ch);
	}

	public static void addStringvalue(String str) {
		System.out.println("Enter the String value to add");
		Scanner sc=new Scanner(System.in);
		String s2 = sc.nextLine();
		System.out.println(str+" "+s2);
		
	}



}

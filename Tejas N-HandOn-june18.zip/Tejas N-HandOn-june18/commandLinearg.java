package org.wipro.june18;

public class commandLinearg {

	public static void main(String[] args) {

		int num=Integer.parseInt(args[0]);
		String res=(num<0)?"Negative":"Postive";
		System.out.println(res);

	}

}
